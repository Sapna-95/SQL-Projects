-- There are 2 csv files present in this zip file. The data contains 120 years of olympics history. There are 2 daatsets 
-- 1- athletes : it has information about all the players participated in olympics
-- 2- athlete_events : it has information about all the events happened over the year.(athlete id refers to the id column in athlete table)

-- import these datasets in sql server and solve below problems:

-- 1 which team has won the maximum gold medals over the years.

-- 2 for each team print total silver medals and year in which they won maximum silver medal..output 3 columns
	-- team,total_silver_medals, year_of_max_silver

-- 3 which player has won maximum gold medals  amongst the players 
	-- which have won only gold medal (never won silver or bronze) over the years

-- 4 in each year which player has won maximum gold medal . Write a query to print year,player name 
	-- and no of golds won in that year . In case of a tie print comma separated player names.

-- 5 in which event and year India has won its first gold medal,first silver medal and first bronze medal
	-- print 3 columns medal,year,sport

-- 6 find players who won gold medal in summer and winter olympics both.

-- 7 find players who won gold, silver and bronze medal in a single olympics. print player name along with year.

-- 8 find players who have won gold medals in consecutive 3 summer olympics in the same event . Consider only olympics 2000 onwards. 
	-- Assume summer olympics happens every 4 year starting 2000. print player name and event name.



-- congratulations you have unlocked datalemur premium subscription:

-- URL : https://datalemur.com/questions
-- username : ashish677568@gmail.com
-- password : Allthebest1



